import reflex as rx
from .model.user_model import User
from .service.user_service import select_all


class UserState(rx.State):
    # 
    users: list[User]
    
    @rx.background
    async def get_all_users(self):
        async with self:
            self.users = select_all()

@rx.page(route='/user', title='User', on_load= UserState.get_all_users)

def user_page() -> rx.Component:
    return rx.flex(
    rx.heading('Usuarios', align='center'),
    #rx.hstack()
    table_user(UserState.users),
    direction='column',
    style={'width':'60vw','margin':'auto'}
)

def table_user(list_users: list[User]) -> rx.Component:
    return rx.table.root(
        rx.table.header(
            rx.table.row(
                rx.table.column_header_cell('id'),
                rx.table.column_header_cell('Nombre'),
                rx.table.column_header_cell('Usuario'),
                rx.table.column_header_cell('Telefono'),
                rx.table.column_header_cell('Accion')
            )
        ),
        rx.table.body(
            rx.foreach(list_users, row_table)
        )
    )

def row_table(user: User) ->rx.Component:
    return rx.table.row(
        rx.table.cell(user.id_user),
        rx.table.cell(user.name),
        rx.table.cell(user.username),
        rx.table.cell(user.phone),
        rx.table.cell(rx.button('Eliminar'))
    )