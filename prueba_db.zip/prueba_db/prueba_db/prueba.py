"""Welcome to Reflex! This file outlines the steps to create a basic app."""

from rxconfig import config

import reflex as rx

docs_url = "https://reflex.dev/docs/getting-started/introduction/"
filename = f"{config.app_name}/{config.app_name}.py"


class State(rx.State):
    """The app state."""

def banner_principal():
    return rx.flex( 
            rx.image(src="/Publicidad1.jpg", width="auto", height="250px"),
            width="100%", justify="center",
        )

def sidebar():
    return rx.vstack(
        rx.image(src="/favicon.ico", width="3em"),
        rx.heading("Sidebar", margin_bottom="1em"),
        position="fixed",
        height="100%",
        left="0px",
        top="0px",
        z_index="5",
        padding_x="2em",
        padding_y="1em",
        background_color="lightgray",
        align_items="left",
        width="250px",
    )

def navbar():
    return rx.hstack(
        #sidebar(),
                rx.hstack(
                    rx.image(src="/favicon.ico", width="2em"),
                    rx.heading("Añemu", font_size="2em"),
                ),
                rx.spacer(),
                rx.chakra.link(
                    "Registrarse", href="/docs/library"
                ),  
                rx.chakra.link(
                    "Acceder", href="/docs/library"
                ), rx.input(placeholder="Buscar...", max_length="20"),
        #position="fixed",
        top="0px",
        #background_color="lightgray",
        #padding="1em",
        #height="4em",
        width="100%",
        #z_index="5",
        class_name="bg-gray-800 text-white p-4 mt-auto",
    )

def muestra_categorias():
    return rx.hstack(
            rx.spacer(
                spacing= "6",
            ),
            rx.flex(
                rx.card("Card 1", size="5"),
                rx.card("Card 2", size="5"),
                rx.card("Card 3", size="5"),
                rx.card("Card 4", size="5"),
                rx.card("Card 5", size="5"),
                spacing="2",
                align_items="flex-start",
                direction="row",
                align="center",
            ),
           # background_color="var(--gray-3)",
            width="70%",
            title="Categorias",
        )

def banner_secundario():
    return rx.flex( 
            rx.image(src="/Publicidad2.jpg", width="auto", height="150px"),
            width="100%", justify="center",
        )

def crea_card_producto():
    return rx.card(
            rx.inset(
                rx.image(
                    src="/tractor.jpg",
                    width="50%",
                    height="auto", 
                    align="center",
                    class_name="mb-2",
                ),
                side="top",
                pb="current",
            ),
            rx.text(
                "Reflex is a web framework to build app in pure Python."
            ),
            width="20vw",
            class_name="bg-white p-4 rounded shadow flex flex-col justify-center items-center",
        )

def anuncios():
    return rx.chakra.responsive_grid(
        crea_card_producto(),
        crea_card_producto(),
        crea_card_producto(),
        crea_card_producto(),
        crea_card_producto(),
        crea_card_producto(),
        crea_card_producto(),
        crea_card_producto(),
        crea_card_producto(),
        auto_columns="auto",
       columns=[4],
       # spacing="4",
        spacing_y="4",
       # spacing_x="4",
        class_name="container mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-4 p-4",
    )

def footer():
    return rx.flex(
            rx.hstack(
                rx.text("Aqui va el footer"),
                align="start",
            ),
            class_name="bg-gray-800 text-white p-4 mt-auto",
        )
    


def index() -> rx.Component:
    return rx.flex(
        navbar(),
        banner_principal(),
        muestra_categorias(),
        banner_secundario(),
        anuncios(),
        footer(),
    direction="column",
    spacing="6",
    )


app = rx.App()
app.add_page(index, title="Avende")