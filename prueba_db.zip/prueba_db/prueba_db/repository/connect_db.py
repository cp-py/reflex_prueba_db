from sqlmodel import create_engine

def connect():
    engine = create_engine("mariadb+mariadbconnector://root:@localhost:3306/agroventas")
    return engine
