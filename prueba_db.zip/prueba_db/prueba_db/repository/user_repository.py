from ..model.user_model import User
from .connect_db import connect
from sqlmodel import Session, select
import reflex as rx

def select_all():
    engine = connect() 
    """with rx.session() as session:
        query = select(User) 
        return session.exec(query).all()"""
    with Session(engine) as session:
        query = select(User)
        return session.exec(query).all() 