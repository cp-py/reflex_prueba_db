import reflex as rx

config = rx.Config(
    app_name="prueba_db",
)